/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.dao;

import java.util.ArrayList;
import java.util.List;
import model.MyBatisUtils;
import model.pojos.Actividad;
import model.pojos.EEPlanTrabajo;
import model.pojos.Evaluacion;
import model.pojos.Maestro;
import model.pojos.ObjetivoParticular;
import model.pojos.Participante;
import model.pojos.PlanDeTrabajo;
import model.pojos.Tema;
import org.apache.ibatis.session.SqlSession;

/**
 * Interface para la clase PlanDeTrabajoDAO.java
 *
 * @author Daniela Hernandez
 * @since Jun 11, 2018
 * @version 1.1
 */
interface InterfacePlanDeTrabajoDAO {
    
    Integer obteneridPlanTrabajo();
    
    Integer obteneridObjetivoParticular();
    
    Integer obteneridEEPlanTrabajo();
    
    PlanDeTrabajo obtenerPlanDeTrabajo(Integer idAcademia);

    PlanDeTrabajo obtenerPlanDeTrabajoEspecifico(Integer idPlanTrabajo);
    
    void actualizarPlanDeTrabajoEspecifico(PlanDeTrabajo plandetrabajo);
    
    void actualizarObjetivoParticularEspecifico(ObjetivoParticular objetivoparticular);
    
    void actualizarEEPlanDeTrabajo(EEPlanTrabajo eeplantrabajo);
    
    List<ObjetivoParticular> obtenerObjetivoParticulares(Integer idPlanDeTrabajo);
            
    ObjetivoParticular obtenerObjetivoParticularEspecifico(Integer idPlanTrabajo);
        
    List<Actividad> obtenerActividades(Integer idObjetivoParticular);

    List<EEPlanTrabajo> obtenerEEPlanDeTrabajo(Integer idPlanDeTrabajo);
    
    List<Evaluacion> obtenerEvaluaciones(Integer idPlanDeTrabajo);
    
    Tema obtenerTemaDeEEPlanTrabajo(Integer idEEPlanDeTrabajo);
    
    List<Maestro> obtenerParticipantes(Integer idPlanDeTrabajo);
    
    boolean guardarEEPlanTrabajo(EEPlanTrabajo ee);

    boolean guardarEvaluacion(Evaluacion eval);

    boolean guardarTema(Tema tema);
    
    boolean guardarObjetivoParticular(ObjetivoParticular obj);
    
    boolean guardarActividad(Actividad act);
    
    boolean guardarParticipante(Participante participante);
    
    boolean guardarPlanDeTrabajo(PlanDeTrabajo plan);

    boolean eliminarActividad(Integer idEEPlanTrabajo);
    
    boolean eliminarEvaluacion(Integer idEEPlanTrabajo);
        
    boolean eliminarParticipante(Integer idPlanDeTrabajo);
    
    boolean eliminarTema(Integer idTema);
        
    boolean eliminarObjetivoParticular(Integer idObjetivoParticular);
    
    boolean eliminarEEPlanTrabajo(Integer idEEPlanTrabajo);
    
    boolean eliminarPlanDeTrabajo(Integer idPlanDeTrabajo);
}
